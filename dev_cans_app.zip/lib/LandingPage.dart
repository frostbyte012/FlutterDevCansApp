import 'package:flutter/material.dart';
class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(
          color: Colors.black,
          child: Column(
            children: [
                 Expanded(
              child: Row(
                children:[
                  Column(
                  children: [
                    Text("Dev",
                         style:TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize:180.0,
                            color: Colors.white,
                         ),
                        ),
                       ]
                  ),
                  Column(
                    children: [
                      SizedBox(
                        height:120,
                      ),
                      Text("Cans.",
                        style:TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize:69.0,
                          color: Colors.purpleAccent,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
                child:Column(
                    children: [

                      Image(image:AssetImage("images/1563770114phpdZwVzd.png"),height: 200.0,width: 200.0,),
                      SizedBox(height: 20,),
                      Text("Welcome",style:TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize:50.0,
                        color: Colors.purpleAccent,
                      ),),
                      Text("to our community coding",style:TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize:25.0,
                        color: Colors.white,
                      ),),
                      SizedBox(
                        height: 50.0,
                      ),
                      FlatButton(
                          onPressed: null, 
                          child:Container(
                            height: 50.0,
                            width:double.infinity,
                              decoration: BoxDecoration(
                                borderRadius:BorderRadius.circular(30.0),
                                color: Colors.purpleAccent,
                              ),
                              child: Center(
                                child: Text("Sign Up",style:TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize:25.0,
                                  color: Colors.white,
                                ),),
                              ),

                          ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      FlatButton(
                        onPressed: null,
                        child:Container(
                          height: 50.0,
                          width:double.infinity,
                          decoration: BoxDecoration(
                            borderRadius:BorderRadius.circular(30.0),
                            color: Colors.white,
                          ),
                          child: Center(
                            child: Text("Sign In",style:TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize:25.0,
                              color: Colors.purpleAccent,
                            ),),
                          ),

                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text("Need Help ?",style:TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize:15.0,
                        color: Colors.green,
                      ),),
                    ],
                ),
              flex: 2,
            ),
           ]
          ),
         ),
      );
  }
}
