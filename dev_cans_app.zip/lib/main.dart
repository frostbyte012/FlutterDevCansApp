import'package:flutter/material.dart';
import 'LandingPage.dart';
void main()=>runApp(DevCans(),);
class DevCans extends StatefulWidget {
  @override
  _DevCansState createState() => _DevCansState();
}

class _DevCansState extends State<DevCans> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:HomePage(),
    );
  }
}
