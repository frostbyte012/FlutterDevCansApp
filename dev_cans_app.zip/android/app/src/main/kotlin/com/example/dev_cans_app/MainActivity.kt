package com.example.dev_cans_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
